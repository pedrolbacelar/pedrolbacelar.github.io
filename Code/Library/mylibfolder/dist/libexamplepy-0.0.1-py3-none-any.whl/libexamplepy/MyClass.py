
class MyClass:
    def __init__(self, parameter):
        self.parameter = parameter  
    def method(self):
        print(f"Hello World, my parameter is {self.parameter}")
